import { Component, OnInit } from '@angular/core';
import { DbEntries } from '../model/dbEntries.model';
import { DbDetailsService } from '../shared/db-details.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  dbToggle:boolean=false;
  errorStatus: any;
  dbdetails:any;
  AuthTypeSourceForm: FormGroup;
  addSourceSecurities: FormArray;
  
  constructor(private dbservice:DbDetailsService, private formBuilder: FormBuilder) { 

    this.AuthTypeSourceForm = this.formBuilder.group({
      addSourceSecurities: this.formBuilder.array([this.TargetSecurityArray()])
    })

  }


  ngOnInit() {
  }
  TargetSecurityArray(): FormGroup {
    return this.formBuilder.group({
      ColoumName: ''
    });
  }
  addDbDetails(dbdetail){
    alert(JSON.stringify(dbdetail))
    // this.store.dispatch(new AddDb(dbdetail));
    this.dbservice.addNewDbData(dbdetail).subscribe(data=>{
     // alert(data);
     //this.messageService.add({key: 'custom', severity:'info', summary: 'Success Message', detail: 'Saved Successfully' });
     //this.router.navigate(['Dashboard/db-list']);
    },err=>{
      this.errorStatus=err.statusText;
      this.dbToggle=true;
    })
     
   }
   addSourceAuthType(): void {
    //alert();
      this.addSourceSecurities = this.AuthTypeSourceForm.get('addSourceSecurities') as FormArray;
      this.addSourceSecurities.push(this.TargetSecurityArray());
    
  }

  deleteSourceAuthType(index) {

    this.addSourceSecurities.removeAt(index);
    
  }
}
